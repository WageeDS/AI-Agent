import re

def parse_recipe(recipe_text):
    """
    Parse the recipe text from Gemini into a structured format.
    
    Args:
        recipe_text (str): Raw recipe text from Gemini
        
    Returns:
        dict: Structured recipe with title, ingredients, and instructions
    """
    recipe = {
        'title': '',
        'ingredients': [],
        'instructions': []
    }
    
    # Extract title
    title_match = re.search(r'# (.+)', recipe_text)
    if title_match:
        recipe['title'] = title_match.group(1).strip()
    
    # Extract ingredients
    ingredients_section = re.search(r'## Ingredients:(.*?)##', recipe_text, re.DOTALL)
    if ingredients_section:
        ingredients_text = ingredients_section.group(1).strip()
        ingredients = re.findall(r'- (.+)', ingredients_text)
        recipe['ingredients'] = [ingredient.strip() for ingredient in ingredients]
    
    # Extract instructions
    instructions_section = re.search(r'## Instructions:(.*?)(?:##|$)', recipe_text, re.DOTALL)
    if instructions_section:
        instructions_text = instructions_section.group(1).strip()
        instructions = re.findall(r'\d+\.\s+(.+)', instructions_text)
        recipe['instructions'] = [instruction.strip() for instruction in instructions]
    
    return recipe

def extract_grocery_list(recipe_text):
    """
    Extract the shopping list from the recipe text.
    
    Args:
        recipe_text (str): Raw recipe text from Gemini
        
    Returns:
        list: Shopping list items
    """
    shopping_list = []
    
    # Extract shopping list section
    shopping_section = re.search(r'## Shopping List:(.*?)(?:##|$)', recipe_text, re.DOTALL)
    if shopping_section:
        shopping_text = shopping_section.group(1).strip()
        items = re.findall(r'- (.+)', shopping_text)
        shopping_list = [item.strip() for item in items]
    
    return shopping_list
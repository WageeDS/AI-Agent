import os
import google.generativeai as genai
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Set up Gemini API
api_key = os.getenv("GEMINI_API_KEY")
genai.configure(api_key=api_key)

def generate_recipe(ingredients, dietary_preferences):
    """
    Generate a recipe using Gemini API based on given ingredients and dietary preferences.
    
    Args:
        ingredients (str): Comma-separated list of ingredients
        dietary_preferences (str): Dietary preferences
        
    Returns:
        str: Generated recipe text
    """
    if not api_key:
        raise ValueError("Gemini API key not found. Please set it in the .env file.")
    
    # Create prompt for Gemini
    prompt = f"""
    You are a professional chef. Create a detailed recipe using some or all of these ingredients: {ingredients}.
    
    If specified, follow these dietary restrictions: {dietary_preferences if dietary_preferences != 'None' else 'No restrictions'}.
    
    Format your response as follows:
    
    # [Recipe Title]
    
    ## Ingredients:
    - [ingredient 1 with quantity]
    - [ingredient 2 with quantity]
    ...
    
    ## Instructions:
    1. [step 1]
    2. [step 2]
    ...
    
    ## Shopping List:
    - [item 1]
    - [item 2]
    ...
    
    The shopping list should include items not mentioned in the provided ingredients list.
    """
    
    try:
        # Use the recommended model (gemini-1.5-flash is free and recommended by Google)
        model = genai.GenerativeModel('gemini-1.5-flash')
        
        # Call Gemini API with safety settings that allow creative content
        generation_config = {
            "temperature": 0.7,
            "top_p": 0.95,
            "top_k": 40,
            "max_output_tokens": 2048,
        }
        
        safety_settings = [
            {"category": "HARM_CATEGORY_HARASSMENT", "threshold": "BLOCK_MEDIUM_AND_ABOVE"},
            {"category": "HARM_CATEGORY_HATE_SPEECH", "threshold": "BLOCK_MEDIUM_AND_ABOVE"},
            {"category": "HARM_CATEGORY_SEXUALLY_EXPLICIT", "threshold": "BLOCK_MEDIUM_AND_ABOVE"},
            {"category": "HARM_CATEGORY_DANGEROUS_CONTENT", "threshold": "BLOCK_MEDIUM_AND_ABOVE"},
        ]
        
        response = model.generate_content(
            prompt,
            generation_config=generation_config,
            safety_settings=safety_settings
        )
        
        # Extract and return the recipe text
        return response.text
        
    except Exception as e:
        raise Exception(f"Error calling Gemini API: {str(e)}")